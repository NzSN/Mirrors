# MirrorECMA

Compare language and worker capabilities in the
[framework map](../Mirrors/Docs/framework-map.md). MirrorECMA remains the Node
application client; native C++/Rust Gate evaluators do not require it at runtime.

For the complete framework map, start with the [application integration guide](../Mirrors/Docs/application-integration-guide.md).
For remote model servers and concurrent jobs, see [remote server usage](docs/remote-server.md).

TypeScript client for [Mirrors](https://github.com/NzSN/Mirrors), the Lean 4
conformance checker compatible with the ModelMirrors JSONL protocol. Connect a
real implementation to a generated typed interface, replay TLA+ model traces,
and let Mirrors compare the implementation's observations with the model.

For a new application, use a generated suite model with `defineSuite` and
`runSuite`, or the installed `mirrorecma init/doctor/generate/check/replay`
commands. The [suite guide](docs/application-suites.md) covers deferred native
adapters, matched coverage and cleanup; the [project guide](docs/project-tools.md)
covers declarative configuration and prepared toolchains. The same suite can use
Gate's optional `evaluateSuite` integration without adding Gate to local replay.

The 2.0 source cutover keeps MirrorECMA focused on MBT against caller-supplied
implementations. A user-started coordinator requests restricted authoring directly
from MirrorGate; Gate's optional `mirrorgate-mirrorecma` integration supplies the
implementation proxy. Core has no Gate dependency, peer, launcher, or sandbox
facade. Generic negotiation, generated binding, replay and report APIs are unchanged.
See the [2.0 migration guide](docs/migration-v2.md) and
[implementation boundary](docs/implementation-boundary-design.md). Source version
2.0.0 is a breaking cutover decision, not a published-release claim.

The [reusable harness design](docs/mbt-harness-design.md) allows the same MBT
suite to run as source-code tests, a CLI, or a proxy-accessible evaluation service.
Implementation proxies and evaluation-service proxies serve different roles;
their wrappers remain outside MirrorECMA's core. Gate's [optional loopback HTTP
service](https://github.com/NzSN/MirrorGate/blob/main/integrations/mirrorecma/service/README.md)
is implemented and locally validated through that same suite.

The [implementation work plan](docs/mbt-integration-tasks.md) records the
extraction, shared-harness, and consumer-validation assignments. Optional
evaluation-service delivery remains separate from core MBT.

The [documentation index](docs/README.md) distinguishes runnable examples,
current APIs, completed migration, implemented hosting/service interfaces, and
historical design records. [Final coordinated validation](https://github.com/NzSN/MirrorGate/blob/main/docs/managed-workflow-validation.md)
records destination tests, full interop, and the real Codex-to-Gate MCP workflow.

## New application quick start

Initialize a declarative project, select the reviewed model/contract/corpus and
pin compatible installed tools, then generate, compile, check, and replay:

```bash
mirrorecma init ./mbt
mirrorecma generate --project ./mbt/mirror.project.json
# Compile the generated <Model>.suite.ts during application preparation.
mirrorecma doctor --project ./mbt/mirror.project.json
mirrorecma check --project ./mbt/mirror.project.json
mirrorecma replay --project ./mbt/mirror.project.json
```

The application implements only the generated native `actions`, `observe`, and
optional domain disposer. The framework derives registry identity, checks the
ordered corpus, defers construction until required match, evaluates matched
action/pair coverage, and joins cleanup. Read the
[project guide](docs/project-tools.md), [suite guide](docs/application-suites.md),
and [application-validation suites](examples/application-validation/README.md).
The complete end-to-end tutorial lives in
[Mirrors](https://github.com/NzSN/Mirrors/blob/main/Docs/mirrorecma-typescript-mbt-user-manual.md).

## Legacy restricted-evaluation migration

This section exists for consumers of the former MirrorECMA sandbox facade. New
Gate-backed applications use the same `SuiteDefinition` through Gate-owned
`evaluateSuite`; see the
[Gate integration guide](https://github.com/NzSN/MirrorGate/blob/main/integrations/mirrorecma/README.md).

Gate-aware callers migrate their imports to the separate Gate-owned package:

```ts
import {
  evaluateSandboxed, createSandboxCompiledModel,
  type SandboxEvaluationPlan,
} from "mirrorgate-mirrorecma/legacy";
```

That explicit compatibility entry retains the previous callback, disclosure and
cleanup semantics; MirrorECMA does not forward these imports or depend on the
integration. Install compatible locally packed packages according to the
[Gate integration guide](https://github.com/NzSN/MirrorGate/blob/main/integrations/mirrorecma/README.md).
The Gate package and integration may be private; no registry availability is
implied. New managed authoring uses Gate-owned `evaluateSuite`, which supplies
the deferred provider to the ordinary MirrorECMA suite after model admission.

The former sandbox tests and 42-row TypeScript/C++ acceptance driver now live
with the Gate integration. Their Node/Rust, owned/attached, required-match,
correct/faulty, source-author and cancellation scenarios remain required. Use
`pnpm run check:package-boundary` with `MIRROR_BIN` to prove that a packed core-only
consumer can compile declarations and run local MBT, mismatch, cancellation and
report checks without either Gate package.

The manual
[required-backend workflow](.github/workflows/shared-orchestration.yml) runs on
a prepared self-hosted Linux runner labeled `mirrorgate-bubblewrap`. Dispatchers
must provide full matching MirrorGate, Mirrors, and MirrorCPP commit SHAs. The
runner repository variables must point to an executable pinned Apalache binary,
the exact Node 24.15.0 runtime tree, and a prepared MirrorCPP dependency cache:
`SHARED_ORCHESTRATION_APALACHE_MC`,
`SHARED_ORCHESTRATION_NODE_RUNTIME_ROOT`, and
`SHARED_ORCHESTRATION_MIRRORCPP_DEPENDENCY_CACHE`. Missing tools, an unavailable
Bubblewrap backend, a dirty or mismatched checkout, a missing matrix row, or a
missing evidence manifest fails the job; there is no skip path.

The same entry point can be run on an equivalently prepared machine with all
four expected revisions and checkout paths explicit:

```bash
MIRRORECMA_ROOT="$PWD" \
MIRRORGATE_ROOT=/checkouts/MirrorGate \
MIRRORS_ROOT=/checkouts/Mirrors \
MIRRORCPP_ROOT=/checkouts/MirrorCPP \
MIRRORECMA_EXPECTED_REV=<40-hex-sha> \
MIRRORGATE_EXPECTED_REV=<40-hex-sha> \
MIRRORS_EXPECTED_REV=<40-hex-sha> \
MIRRORCPP_EXPECTED_REV=<40-hex-sha> \
APALACHE_MC=/opt/apalache/bin/apalache-mc \
MIRRORGATE_NODE_RUNTIME_ROOT=/opt/node-v24.15.0-linux-x64 \
MIRRORCPP_DEPENDENCY_CACHE=/opt/mirrorcpp-deps \
bash tools/ci/shared-orchestration.sh
```

Ordinary `pnpm run check` and client tests remain independent of these prepared
backend prerequisites. A local green run does not create a hosted-CI or release
support claim; the acceptance ledger records each evidence class separately.

## Low-level synchronous generated-binding example

The [runnable Counter tutorial](examples/generated-counter/README.md) starts
with an ordinary implementation. It uses `bigint` and has no protocol dependency:

```ts
export class Counter {
  count = 0n;

  reset(): void {
    this.count = 0n;
  }

  increment(stride: bigint): void {
    this.count += stride;
  }
}
```

The [TLA+ model](examples/generated-counter/specs/Counter.tla) describes the
expected transitions. Its
[companion contract](test/fixtures/model-interface/counter/Counter.mirror-interface.json)
maps initialization to `init`, an increment to `tick`, and the observation to
`count`. Mirrors generates the typed port and binding from that contract and
structural type evidence. The checked-in
[generated source](test/fixtures/model-interface/counter/generated/CounterMirror.generated.ts)
includes:

```ts
export interface TickInput {
  readonly stride: bigint;
}

export interface CounterObservation {
  readonly count: bigint;
}

export interface CounterPort {
  initialize(): void;
  tick(input: TickInput): void;
  observe(): CounterObservation;
}
```

The handwritten [adapter](examples/generated-counter/adapter.ts) maps that port
to the real [Counter](examples/generated-counter/counter.ts):

```ts
const port: CounterPort = {
  initialize: () => counter.reset(),
  tick: ({ stride }) => counter.increment(stride),
  observe: () => ({ count: counter.count }),
};
```

The compiled registry factory creates `counter` and this port only after Mirrors
confirms the generated interface. The generated binding handles input decoding,
action dispatch, observation encoding, and lifecycle checks. The adapter reads
the implementation's actual count after each operation.

With Node.js, pnpm, and the
[Mirrors build prerequisites](https://github.com/NzSN/Mirrors#requirements)
installed, run these commands from the **MirrorECMA root**. Set `MIRRORS_ROOT`
to the absolute path of your Mirrors checkout; the example defaults to the
sibling `../Mirrors` layout when the variable is omitted.

```bash
pnpm install --frozen-lockfile
export MIRRORS_ROOT=/absolute/path/to/Mirrors
(cd "$MIRRORS_ROOT" && lake build mirror model_interface_gen)
pnpm run check:examples
pnpm run smoke:generated-counter
pnpm run example:counter
```

The smoke gate checks model provenance, generated artifacts, action coverage,
and both implementations. The example then replays the checked-in trace over
local stdio, without invoking Apalache. Set `MIRROR_BIN` to an absolute executable
path to override `$MIRRORS_ROOT/.lake/build/bin/mirror`.

Run the same adapter against `BrokenCounter`, whose increment adds
`stride - 1n`:

```bash
pnpm run example:counter:broken
```

This command intentionally exits nonzero: Mirrors detects a `tick` mismatch on
`count`. The observer still reports the real value. Follow the
[full tutorial](examples/generated-counter/README.md) for expected diagnostics,
read-only artifact checks, regeneration, and fresh Apalache traces. Passing
establishes agreement on the observations and traces exercised; action counts
show which handlers ran.

Next, the [asynchronous work queue](examples/work-queue/README.md) exercises
multiple actions, failures, retries, and reset through a real implementation.
The [three-application validation program](examples/application-validation/README.md)
adds persistent transfers and controlled-clock leases, pinned fault matrices,
fresh model witnesses, private receipts, and real Gate worker/authoring checks.
[Reports and asynchronous replay](docs/replay-and-async.md) explain structured
failures, cancellation, generated async ports, and dynamic factory ownership.

This example is retained for synchronous-profile compatibility and for callers
that need direct registry control. It is not the default new-application path.

Advanced paths remain available below: [compiled and dynamic bindings](#verified-generated-bindings),
[low-level customization](#low-level-customization),
[symbolic exploration](#architecture), [transports](#transports), and
[async server jobs through `Connection`](src/connection.ts).

## Architecture

The **TLA+ spec is the test oracle**; your TypeScript state machine is the
system under test (SUT). The Mirrors server sits between the model
checker and your code: it obtains expected states from the model via
apalache-mc and conformance-checks every state the SUT reports
(variable-by-variable equality, `diffState`).

```
               model side                        SUT side
┌──────────────┐  JSON-RPC  ┌─────────┐ JSON-lines ┌──────────┐
│ apalache-mc  │◄──────────►│ mirror  │◄══════════►│ your SUT │
│ (CLI/server) │            │ (daemon)│ stdio | TCP│(this lib)│
└──────────────┘            └─────────┘            └──────────┘
     produces expected states        checks reported states
```

Three oracle modes, all transport-agnostic:

1. **Trace replay** (`runClient`, `runClientWithTraces`, `runClientGenTraces`)
   — apalache generates counterexample traces (an "invariant" like
   `step_count < N` is violated on purpose); the mirror replays them
   step-by-step and the SUT must reproduce every state.
2. **Mirror-driven symbolic MBT** (`runClientExplore`) — the mirror drives a
   live apalache explorer server, computing each successor state
   *symbolically* (no pregenerated trace), and checks state invariants after
   every step.
3. **Client-driven symbolic MBT** (`startExploreSession`) — the mirror proxies
   raw explorer commands; your test script controls the exploration:
   `assumeTransition`/`nextStep` to walk, `queryState` to read the oracle,
   `assumeState` to force concrete scenarios, `checkInvariant` to probe,
   `rollback` to backtrack.

**Physical separation:** spec sources (with their `EXTENDS` dependency
closure) travel inline inside `register`/`register_trace_gen`
(`specFromFiles`), and the mirror can run as a TCP daemon (`--serve <port>`)
— a remote mirror needs nothing but the apalache toolchain. `register_traces`
is the exception: its trace paths are mirror-local.

**The harness is itself model-checked:** the message layer conforms to
`ModelMirros/specs/MirrorProtocol.tla`, verified by MBT tests that replay
spec-generated protocol traces against the real mirror implementation.


## Install & Build

```bash
pnpm install --frozen-lockfile
pnpm run build        # → dist/
pnpm run check        # type-check only
pnpm run check:package-boundary # packed core-only declarations + local MBT (requires MIRROR_BIN)
MIRRORS_FIXTURES=/path/to/Mirrors/test/fixtures pnpm test
MIRROR_BIN=/path/to/Mirrors/.lake/build/bin/mirror \
  SPEC=/path/to/authoritative/Counter.tla pnpm run smoke
```

`SPEC` is optional; the smoke suite defaults to its checked-in
`specs/Counter.tla`. The smoke suite generates traces from that model, replays
every state through the JavaScript implementation, and then verifies that an
extra observable state key is rejected with terminal `step_mismatch` over
stdio, TCP, and mTLS. `MIRRORS_FIXTURES` selects the canonical wire corpus;
the sibling `../Mirrors/test/fixtures` checkout is the default.

## Reproducible checks

The same focused command runs on client pushes and pull requests:

```bash
MIRRORS_ROOT=/absolute/path/to/Mirrors pnpm run ci
```

It checks the [published tool/compiler pins](scripts/ci/versions.env), all three
TypeScript configurations, Jest, Counter artifact freshness, generated async
Counter replay, and passing/faulty Counter and work-queue executables. Install
the locked dependencies first. For an explicitly paired newer server commit,
set `MIRRORS_REF` to its full SHA; update
the checked baseline after publishing and verifying that pair. Manual CI also
accepts a matching `mirrors_ref` and an optional live Apalache tier. See the
[CI design](docs/superpowers/specs/2026-09-06-reproducible-ci-design.md) for local
live commands and the broader cross-client matrix.

## Reports and asynchronous implementations

The existing replay entry points retain `Promise<void>` results. Their additive
`WithReport` variants without an explicit execution selection return an immutable, JSON-safe `ReplayReport`; failures
throw and expose partial progress through `replayReportFromError(error)`.
`ReplayMismatchError` includes the action, inputs, trace/state position,
expected/actual values, and ordered diff hints. Reports encode arbitrary-size
integers as ITF `#bigint` decimal strings, so `JSON.stringify(report)` preserves
them exactly.

Ordinary trace replay also accepts asynchronous computers. For a generated
asynchronous port, select `mirrorecma-async-v1` and the separate local contract
`mirrors.async-state-computer/v1`; the synchronous target stays compatible.
Dynamic handlers opt in with a factory scope whose `execution` is `"async"`.
Both paths await an operation and its observations before reporting state.
`ReplayCallbackContext.signal`, `actionTimeoutMs`, and `receiveTimeoutMs` provide
cooperative cancellation and per-operation limits. Application I/O must honor
the signal; a timeout cannot undo a completed mutation or stop code that ignores
it. Read the [API guide and cancellation limits](docs/replay-and-async.md) before
connecting resource-owning or asynchronous implementations.

## Verified generated bindings

`runClientNegotiated` verifies a compiler-generated binding against current
Mirrors before constructing its local adapter. Generated metadata contains the
canonical companion contract and semantic digest; Mirrors independently
resolves that contract from the exact spec, trace evidence, and run profile.
No generated source crosses the wire.

The [complete Counter adapter](examples/generated-counter/adapter.ts) is the
production-oriented **D3 compiled verification** path. `createCounterRun()`
registers a factory using the generated metadata/digest pair, an exact adapter
ID, and the exported target-profile and StateComputer-contract versions. It
uses `policy: "require"`. Registry lookup is exact and pure; its factory creates
the Counter, port, and binding only after a validated `matched` response.
The negotiated runner disposes every created binding once.

For development, **D4 dynamic descriptor mode** retrieves an inert semantic
descriptor and binds it only to explicitly supplied local handlers. It never
downloads source or executable code, evaluates descriptor content, loads a
module, or infers handlers:

```ts
import {
  DescriptorCache,
  runClientNegotiated,
  semanticDigestFromHex,
} from "mirrorecma";
import { Counter } from "./examples/generated-counter/counter.js";
import {
  CounterModelInterface,
  CounterSemanticDigest,
} from "./test/fixtures/model-interface/counter/generated/CounterMirror.generated.js";

await runClientNegotiated(binaryOrTransport, apalacheConfig, traceConfig, {
  mode: "dynamic",
  contract: CounterModelInterface.contract,
  semanticDigest: CounterSemanticDigest,
  descriptorCache: new DescriptorCache(),
  createRegistry: () => {
    const counter = new Counter(); // only after descriptor verification
    return {
      execution: "sync",
      registry: {
        semanticDigest: semanticDigestFromHex(CounterSemanticDigest),
        actions: {
          Initialize: () => counter.reset(),
          Tick: (inputs) => {
            if (typeof inputs.Stride !== "bigint") throw new Error("invalid stride");
            counter.increment(inputs.Stride);
          },
        },
        observations: { Count: () => counter.count },
      },
      dispose: () => {}, // close application resources here when needed
    };
  },
  policy: "require",
});
```

The dynamic binder validates the descriptor digest, exact handler/observer ID
sets, supported types, projections, native values, and lifecycle before or
during replay. Inputs are deeply readonly records keyed by stable input ID;
observers return native values (`bigint`, booleans, strings, null, arrays,
closed objects, map-entry pairs, `{ tag, value }` variants, or validated
`OpaqueItfValue` wrappers). A failure poisons that session binding.

The factory form owns a returned registry scope and attempts its cleanup exactly
once even if subsequent binding validation fails. Existing callers may still
pass a prebuilt `registry`; that form cannot defer resources the caller has
already constructed. Use `createRegistry` when construction must follow
negotiation. See [dynamic scopes and opaque values](docs/replay-and-async.md#dynamic-factory-scopes)
for the async scope and value boundaries.

Both modes default to `require`. Under `prefer`, legacy continuation requires
an explicit fresh `fallbackFactory`; a digest mismatch never falls back.
Descriptor cache validators are sent only for a verified entry at the exact
registry digest, and `not_modified` fails closed without that entry.

Plain TCP has no model-interface authorization by default. For mTLS
verification, the Mirrors server must explicitly allowlist the client leaf
certificate fingerprint with `--model-interface-allow-client`. Dynamic
descriptor delivery additionally requires `--model-interface-descriptor-read`.

## Low-level customization

Implement `StateComputer` directly when the callback itself is your state
machine, or when you need to own dispatch and state encoding. For an existing
application, start with the [application suite](#new-application-quick-start) so that operations
reach the implementation and observations report its actual state.

This lower-level example uses the separate root `specs/Counter.tla` model:

```ts
import { runClient, getParam } from "mirrorecma";

await runClient(
  "/path/to/Mirrors/.lake/build/bin/mirror",
  {
    specPath: "specs/Counter.tla",
    invariant: "TraceComplete",
    lengthBound: 6,
    constInit: "CInit",
    paramVars: "parameters",
  },
  { numTraces: 1, view: "View" },
  (action, params, prev) => {
    if (action === "init") return { count: { tag: "int", val: 0n } };
    if (action !== "tick") throw new Error(`Unknown action: ${action}`);
    const stride = getParam(params, "parameters")?.stride;
    const count = prev.count;
    if (stride?.tag !== "int" || count?.tag !== "int") {
      throw new Error("Counter requires integer stride and count");
    }
    return { count: { tag: "int", val: count.val + stride.val } };
  },
);
```

## API

### `runClient(target, apalacheConfig, traceConfig, compute, opts?)`

Connects to a ModelMirros binary, registers a spec, and replays all
traces. Throws on step mismatch or protocol error. Returns when `all_steps_done`
is received.

`target` is either a binary path (spawns the mirror over stdio) or a
`Transport` (e.g. `connectMirror(host, port)` — see TCP transport). `opts`
accepts `{ spec?, signal?, actionTimeoutMs?, receiveTimeoutMs? }`. `spec` carries
inline sources (when given, `apalacheConfig.specPath` is ignored by the mirror).
The timeout and signal behavior is defined in the
[replay guide](docs/replay-and-async.md#cancellation-and-timeouts).

The `compute` function is called with:

| Event | Args | Expected return |
|---|---|---|
| `initial_state` | `(action, stateFromMirror, {}, context)` | Initial observed `State` or `Promise<State>` |
| `next_step` | `(action, params, prevState, context)` | Next observed `State` or `Promise<State>` |

Existing three-argument synchronous callbacks remain valid. The generated port
exposes only its typed operation inputs and observations, keeping expected model
state out of the application adapter.

### `presetClient(states)` → `StateComputer`

Returns a compute function that serves states from a pre-defined array in order.
Useful for deterministic specs and testing.

```ts
const states = [
  { count: v(0), step_count: v(0) },
  { count: v(1), step_count: v(1) },
  // ...
];
await runClient(bin, spec, config, presetClient(states));
```

### `runClientExplore(target, spec, invariants, exports, maxSteps, compute)`

Mirror-driven **interactive symbolic model checking**. Instead of replaying
precomputed concrete traces, the mirror starts a live apalache explorer server
and computes each successor state symbolically; your `compute` implementation is
conformance-checked against those states. The message flow is identical to
`runClient` (`spec_validated` → `initial_state`/`next_step` → … → `all_steps_done`).

```ts
const spec = await specFromFile("./specs/HourClock.tla");
await runClientExplore(bin, spec, ["Inv"], [], 4, computer);
```

| Arg | Description |
|---|---|
| `spec` | `ApalacheSpec` (`{ sources: string[] }`) — TLA+ source text; use `specFromFile` |
| `invariants` | Names of state-invariant operators, checked after every step |
| `exports` | Operator names declared for later `OPERATOR`-kind RPC queries. Unused by the mirror's current session commands — pass `[]` |
| `maxSteps` | Exploration depth; `all_steps_done` is sent when it is reached |

Differences from the trace flows:

- `next_step.parameters` carries the **full expected state** (not
  paramVars-extracted params), so a computer may echo it — but an independent
  implementation makes the check non-vacuous.
- The reported state must contain **every** state variable, including
  `action_taken` if the spec has one (the mirror derives action names from it).
  The `paramVars` omit-from-report rule does not apply.

### `startExploreSession(target, spec, invariants, exports)` → `ExploreSession`

Client-driven symbolic checking: opens an explorer session and lets you issue
explorer commands yourself; the mirror proxies each one to the apalache server.

```ts
const session = await startExploreSession(bin, spec, ["Inv"], []);
session.ready;            // { initTransitions, nextTransitions, stateInvariants }

await session.assumeTransition(0);   // → "ENABLED" | "DISABLED" | "UNKNOWN"
await session.nextStep();            // → step number
const state = await session.queryState();
await session.checkInvariant(0);     // → "SATISFIED" | "VIOLATED" | "UNKNOWN"
await session.assumeState({ hr });   // → "ENABLED" | "DISABLED" | "UNKNOWN"
await session.rollback(0);           // → snapshot id
await session.done();                // ends the session and closes the mirror
```

Commands and replies strictly alternate. A `protocol_error`, malformed reply,
or impossible reply closes and poisons the session. The failing call throws;
later calls report that the session is closed. `invariantId` indexes into the
`invariants` list passed at open.

### `specFromFile(path)` → `ApalacheSpec`

Reads a TLA+ file into the `{ sources: [text] }` shape expected by the explore
registration messages.

### `specFromFiles(rootPath, searchDirs?)` → `ApalacheSpec`

Reads a root TLA+ file **and its dependency closure** (`EXTENDS` / `INSTANCE`
clauses, resolved transitively as `<Name>.tla` next to the importing file, then
in `searchDirs`). When `searchDirs` is omitted it defaults to the
`TLA_LIBRARY_PATH` environment variable (colon-separated). Builtin modules
(`Naturals`, `Integers`, `Sequences`, …) are skipped. A module name found in
more than one directory is an **ambiguity error** (the wrong file would
otherwise be shipped silently). The result is `{ sources: [root, ...deps] }` —
root first, as apalache requires.

### Inline spec sources (remote mirrors)

`register` and `register_trace_gen` accept an optional `spec` field carrying
the spec's full source text. When present, the mirror materializes the sources
to a temp directory and **ignores `apalacheConfig.specPath`** — the mirror
never needs filesystem access to the client's files. This is what makes
running the mirror on another machine possible.

```ts
const spec = await specFromFiles("./specs/ExtMain.tla"); // resolves EXTENDS deps
await runClient(bin, { specPath: "ignored", invariant: "TraceComplete", lengthBound: 3 },
  { numTraces: 1 }, compute, { spec });
```

Note: `register_traces` sends `itfTracePaths`, which remain **mirror-local** —
for remote mirrors use `register`, `register_trace_gen`, or the explore flows.
`register_trace_gen` returns the generated traces **inline** in its result as
`itfTraces` (alongside the mirror-local `itfTracePaths` from `gen_traces_done`),
so the client never needs the mirror's filesystem.

### TCP transport

All client entry points accept either a binary path (spawns the mirror over
stdio, as before) or a `Transport`. `connectMirror` provides a TCP transport;
run the mirror as a daemon with `--serve <port>` (one protocol session per
connection, bounded concurrent worker pool):

```ts
// mirror side:  ModelMirrors --serve 8823
import { connectMirror, runClient } from "mirrorecma";

await runClient(connectMirror("192.168.1.10", 8823), apalacheConfig, traceConfig, compute);
// or await startExploreSession(connectMirror("192.168.1.10", 8823), spec, ["Inv"], []);
```

The wire format is the same JSON-lines as stdio. Plain TCP, no TLS — use
SSH/stunnel for untrusted networks.

### Server mode (mTLS)

Beyond `--serve`, ModelMirros runs as a TLS 1.3 server with **mutual
authentication** (`ModelMirrors --server <port> --tls --cert ... --key ...
--ca ...`). `connectTlsMirror` provides the mTLS transport, and
`connectMirrorFromRegistry` adds optional Consul service-registry discovery:

```ts
// mirror side:  ModelMirrors --server 8999 --tls \
//                 --cert server.crt --key server.key --ca ca.crt
import { connectTlsMirror, runClient } from "mirrorecma";

const transport = await connectTlsMirror("10.0.0.5", 8999, {
  caPath: "./certs/ca.crt",
  certPath: "./certs/client.crt",
  keyPath: "./certs/client.key",
});
await runClient(transport, apalacheConfig, traceConfig, compute);
```

Certificate prerequisites (the same files/paths the Haskell client takes):

- `ca.crt` — the private CA bundle that signed the server certificate; the
  client verifies the server chain (and the server verifies the client cert)
  against it.
- `client.crt` / `client.key` — a client certificate and key signed by that
  CA. On POSIX the key must be mode `0600` (not accessible by group/other);
  `connectTlsMirror` rejects otherwise.
- TLS is pinned to **1.3 only**; no older versions are negotiated.
- Server identity is checked against SAN only. DNS names use DNS SAN + SNI;
  IP literals use IP SAN and are not sent as SNI. A CN-only certificate is
  rejected.

Fingerprint pinning (optional, defense in depth): pass `pin` to
`connectTlsMirror` — lowercase hex SHA-256 over the **raw DER** encoding of
the server leaf certificate. The registry helper supplies it automatically
from Consul `Meta["cert-sha256"]`; when you do pass `pin`, it **overrides**
the registry metadata (like the Haskell client's explicit `--pin`).

Discovery with `connectMirrorFromRegistry` — candidates come from
`GET <url>/v1/health/service/modelmirrors?passing=true`, are tried in
registry order, and a failed handshake or pin check closes that candidate and
tries the next. A registry that is unreachable, non-2xx, or malformed yields
no candidates (fail closed):

```ts
import { connectMirrorFromRegistry, runClient } from "mirrorecma";

const transport = await connectMirrorFromRegistry("http://consul.local:8500", {
  caPath: "./certs/ca.crt",
  certPath: "./certs/client.crt",
  keyPath: "./certs/client.key",
});
await runClient(transport, apalacheConfig, traceConfig, compute);
```

On the wire it is still the same JSON-lines session protocol — the first
message is a `register`/`register_traces`/`register_trace_gen`/
`register_explore`/`register_explore_session` — and all client flows work
unchanged over the TLS transport.


### `ApalacheConfig`

| Field | Type | Description |
|---|---|---|
| `specPath` | `string` | Path to the .tla file **on the mirror's filesystem** (ignored when inline `spec` is given) |
| `invariant` | `string` | Invariant to violate (Apalache `--inv`) |
| `lengthBound` | `number` | Max Next steps (Apalache `--length`) |
| `initPredicate?` | `string \| null` | Init operator override (`--init`) |
| `nextPredicate?` | `string \| null` | Next operator override (`--next`) |
| `constInit?` | `string \| null` | Constant initialization operator (`--cinit`) |
| `paramVars?` | `string` | Variable to treat as action parameters |

### `TraceGenerationConfig`

| Field | Type | Description |
|---|---|---|
| `numTraces` | `number` | Number of counterexample traces (`--max-error`) |
| `view?` | `string` | State-view operator (`--view`) |

### `StateComputer`

```ts
type StateComputer = (action: string, params: State, prevState: State) => State;
```

This remains the synchronous callback type, including for symbolic exploration.
The ordinary trace runners accept the additive `ReplayComputer` type:

```ts
type ReplayComputer = (
  action: string, params: State, prevState: State, context: ReplayCallbackContext,
) => State | Promise<State>;
```

It reports the implementation state as `Record<string, Value>` after the
operation settles. [Async replay](docs/replay-and-async.md) covers the context,
limits, and generated/dynamic alternatives. Server asynchronous jobs through
`Connection` are a separate protocol capability.

### Value Helpers

```ts
getParam(state, "parameters")       // extract nested record from state
getParamInt(state, "parameters", "stride")  // extract int field from nested record
asInt(value)    // → bigint | null
asStr(value)    // → string | null
asRecord(value) // → Record<string, Value> | null
```

## Protocol

Client and mirror exchange newline-delimited JSON, one message per line,
tagged by `proto_step`. The same framing runs over stdio (spawned child) or
TCP (`--serve <port>` daemon + `connectMirror`).

Outbound lines must be non-empty, contain no embedded LF, and be at most
65,535 UTF-8 bytes before the terminating LF. All transports enforce these
rules before writing.

### Message catalog

**Client → Mirror:**

| `proto_step` | Fields | Purpose |
|---|---|---|
| `register` | `apalacheConfig`, `traceConfig`, `spec?` | Generate traces, then replay them against the SUT |
| `register_traces` | `apalacheConfig`, `itfTracePaths` | Replay precomputed ITF traces (paths are mirror-local) |
| `register_trace_gen` | `apalacheConfig`, `traceConfig`, `destPath`, `spec?` | Generate trace files only (no replay) |
| `register_explore` | `spec`, `invariants`, `exports`, `maxSteps` | Mirror-driven symbolic exploration + conformance |
| `register_explore_session` | `spec`, `invariants`, `exports` | Open a client-driven explorer session |
| `report_state` | `state` | SUT's state in response to `initial_state`/`next_step` |
| `explore_assume_transition` | `transitionId` | Session command: prepare transition |
| `explore_next_step` | — | Session command: advance one step |
| `explore_query_state` | — | Session command: read current state |
| `explore_check_invariant` | `invariantId` | Session command: check state invariant |
| `explore_assume_state` | `state` | Session command: constrain current state |
| `explore_rollback` | `snapshotId` | Session command: revert to a snapshot |
| `explore_done` | — | Close the session |

**Mirror → Client:**

| `proto_step` | Fields | Purpose |
|---|---|---|
| `spec_validated` | `result`: `"valid"` \| `{invalid}` | Spec accepted; replay/exploration begins |
| `initial_state` | `action`, `state` | First expected state |
| `next_step` | `action`, `parameters` | Next expected step (explore: full state in `parameters`) |
| `step_ok` | — | Reported state matched |
| `step_mismatch` | `expected`, `actual` | Conformance failure; run aborts |
| `all_steps_done` | — | All traces/steps verified |
| `gen_traces_done` | `itfTracePaths` | Trace files written (paths on the mirror) |
| `explorer_ready` | `initTransitions`, `nextTransitions`, `stateInvariants` | Session opened |
| `explore_transition_status` / `explore_assume_status` | `status`: `ENABLED` \| `DISABLED` \| `UNKNOWN` | Command result |
| `explore_step_done` | `stepNo` | Step advanced |
| `explore_state` | `state` | Current symbolic state |
| `explore_invariant_status` | `status`: `SATISFIED` \| `VIOLATED` \| `UNKNOWN` | Invariant result |
| `explore_rollback_done` | `snapshotId` | Reverted |
| `explore_session_done` | — | Session closed cleanly |
| `register_error` | `error` | Registration failed (bad spec/sources); run ends |
| `protocol_error` | `error` | Protocol violation; the affected connection is closed/poisoned |

`spec` fields have the shape `{ sources: [root, ...deps] }` (TLA+ source
text, root module first — apalache resolves `EXTENDS` across them).

### Flows

Trace replay (`register`, `register_traces`) and mirror-driven explore
(`register_explore`) share the same stepping loop:

```
client                        mirror
  |-- register(...) ------------>|
  |<-- spec_validated -----------|
  |<-- initial_state(action, s) -|
  |-- report_state(s) ---------->|
  |<-- step_ok ------------------|
  |<-- next_step(action, p) -----|
  |-- report_state(s') --------->|
  |          ... repeat ...      |
  |<-- all_steps_done -----------|
```

Generation only (`register_trace_gen`):

```
  |-- register_trace_gen(...) --->|
  |<-- gen_traces_done(paths) ----|
```

Explorer session (`register_explore_session`) — commands and replies
strictly alternate until done:

```
  |-- register_explore_session -->|
  |<-- explorer_ready ------------|
  |-- explore_assume_transition ->|
  |<-- explore_transition_status -|
  |-- explore_next_step --------->|
  |<-- explore_step_done ---------|
  |-- explore_query_state ------->|
  |<-- explore_state -------------|
  |          ... any order ...    |
  |-- explore_done -------------->|
  |<-- explore_session_done ------|
```

### Transports

| Mode | Client side | Mirror side | Notes |
|---|---|---|---|
| stdio | `spawnMirror(binPath)` (implicit when passing a path string) | default (no args) | Local child process |
| TCP | `connectMirror(host, port)` | `ModelMirrors --serve <port>` | One session per connection; bounded concurrent worker pool; plain TCP |
| Server (mTLS) | `connectTlsMirror(host, port, tls)` / `connectMirrorFromRegistry(url, tls)` | `ModelMirrors --server <port> --tls --cert ... --key ... --ca ... [--registry <url>]` | mTLS, TLS 1.3 only; optional Consul discovery (`--registry`) + fingerprint pinning |

The message layer is model-checked: `ModelMirros/specs/MirrorProtocol.tla`
defines the legal sequences, and ModelMirros' MBT tests replay spec-generated
protocol traces against the real mirror implementation.

## Value Format

State maps use the Apalache ITF value encoding:

| Type | JSON |
|---|---|
| Int | `{"#bigint": "42"}` |
| Bool | `true` / `false` |
| Str | `"hello"` |
| Set | `{"#set": [{"#bigint": "1"}, {"#bigint": "2"}]}` |
| Tuple | `{"#tup": [...]}` |
| Record | `{"field": value, ...}` |

In the tagged `Value` representation these become `{ tag: "int", val: 42n }`,
`{ tag: "record", val: { field: ... } }`, etc.

## Known Issues
### CJS output with `"type": "module"`

> **Update (2026-08-19):** `package.bazel.json` now declares
> `"type": "module"`, matching the ESM output of `ts_project(module:
> "node16")` (the Bazel execroot picks up the repo `package.json`'s
> `"type": "module"`, so tsc emits ESM). The Bazel build and its
> `//:smoke` test are self-consistent; the workaround below is only needed
> when consuming a Bazel build pinned before this change.

When built via Bazel's `ts_project(transpiler = "tsc")`, the compiled `.js` output is
ESM (`export` / `import`); with an older `package.bazel.json`
(`"type": "commonjs"`) the declared type disagreed with that output.  A
`"type"` mismatch means:

- **Node.js in ESM mode** (including Jest with `ts-jest/presets/default-esm`)
  cannot import named exports from the package — it sees `"type": "module"`,
  treats the `.js` files as ESM, and fails because they contain CJS syntax.
- **Jest cannot transform the module** because the default
  `transformIgnorePatterns` excludes `/node_modules/`.

#### Workaround (used by projects consuming MirrorECMA)

Create a local ESM wrapper that loads the CJS module via `createRequire` and
re-exports its symbols:

```bash
# In the consuming project's test / build script:
cp -rL "$(bazel-out)/node_modules/mirrorecma" node_modules/mirrorecma
chmod -R u+w node_modules/mirrorecma

# Create an .mjs wrapper (always ESM, regardless of "type" field):
cat > node_modules/mirrorecma/index.mjs <<'ESM'
import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
const cjs = require("./src/index.js");
export const {
  runClient, presetClient, encodeClientMessage, encodeState,
  decodeMirrorMessage, asInt, asStr, asRecord, getParam, getParamInt,
  spawnMirror,
} = cjs;
ESM

# Override package.json to point main → index.mjs and set type → commonjs:
cat > node_modules/mirrorecma/package.json <<'PKGJSON'
{
  "name": "mirrorecma",
  "version": "1.0.0",
  "type": "commonjs",
  "main": "index.mjs",
  "types": "index.d.ts"
}
PKGJSON
```

This makes the CJS source files load correctly as CommonJS while exposing
proper named ESM exports to the consuming project.

#### Proper Fix

The root cause should be addressed in MirrorECMA's build configuration:
either compile to ESM output (e.g. set `"module": "es2022"` in tsconfig) or
remove `"type": "module"` from the package.json so the published package is
recognised as CommonJS.

## Deterministic scheduling

Experimental cooperative scheduling, generated replay integration and finite
exploration are documented in [deterministic scheduling](docs/deterministic-scheduling.md).
Concrete acceptance remains tied to the selected artifacts and application profile.
