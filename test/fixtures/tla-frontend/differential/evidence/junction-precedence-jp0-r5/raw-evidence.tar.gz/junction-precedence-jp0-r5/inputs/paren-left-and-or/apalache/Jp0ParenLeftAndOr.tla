---- MODULE Jp0ParenLeftAndOr ----

CONSTANTS A, B, C

Value == (A /\ B) \/ C

====
