---- MODULE Jp0MixedOrAnd ----

CONSTANTS A, B, C

Value == A \/ B /\ C

====
