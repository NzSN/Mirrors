---- MODULE Jp0ParenRightAndOr ----

CONSTANTS A, B, C

Value == A /\ (B \/ C)

====
