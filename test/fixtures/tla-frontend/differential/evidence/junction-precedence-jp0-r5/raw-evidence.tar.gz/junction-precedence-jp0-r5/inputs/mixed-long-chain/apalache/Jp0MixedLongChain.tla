---- MODULE Jp0MixedLongChain ----

CONSTANTS A, B, C

Value == A /\ B /\ C \/ A

====
