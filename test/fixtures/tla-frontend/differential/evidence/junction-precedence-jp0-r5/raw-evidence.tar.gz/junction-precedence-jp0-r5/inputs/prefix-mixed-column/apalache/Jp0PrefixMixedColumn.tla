---- MODULE Jp0PrefixMixedColumn ----

CONSTANTS A, B, C

Value == /\ A
         \/ B

====
