---- MODULE Jp0ParenRightOrAnd ----

CONSTANTS A, B, C

Value == A \/ (B /\ C)

====
