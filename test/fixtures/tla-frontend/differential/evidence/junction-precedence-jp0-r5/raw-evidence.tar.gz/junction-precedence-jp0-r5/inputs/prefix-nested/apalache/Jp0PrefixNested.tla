---- MODULE Jp0PrefixNested ----

CONSTANTS A, B, C

Value == /\ A
         /\ \/ B
            \/ C

====
