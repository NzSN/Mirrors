---- MODULE Jp0WordMixedAlias ----

CONSTANTS A, B, C

Value == A \land B \lor C

====
