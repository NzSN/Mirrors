---- MODULE Jp0ParenLeftOrAnd ----

CONSTANTS A, B, C

Value == (A \/ B) /\ C

====
