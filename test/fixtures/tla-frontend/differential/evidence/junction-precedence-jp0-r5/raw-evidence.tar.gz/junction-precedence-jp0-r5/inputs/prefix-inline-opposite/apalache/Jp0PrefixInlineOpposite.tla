---- MODULE Jp0PrefixInlineOpposite ----

CONSTANTS A, B, C

Value == /\ A \/ B

====
