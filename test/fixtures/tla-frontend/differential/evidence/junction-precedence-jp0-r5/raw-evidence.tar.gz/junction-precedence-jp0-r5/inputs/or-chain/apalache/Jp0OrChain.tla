---- MODULE Jp0OrChain ----

CONSTANTS A, B, C

Value == A \/ B \/ C

====
