---- MODULE Jp0PrefixAnd ----

CONSTANTS A, B, C

Value == /\ A
         /\ B
         /\ C

====
