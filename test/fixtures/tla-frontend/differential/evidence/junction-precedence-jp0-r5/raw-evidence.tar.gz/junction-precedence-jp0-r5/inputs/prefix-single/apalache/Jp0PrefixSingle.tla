---- MODULE Jp0PrefixSingle ----

CONSTANTS A, B, C

Value == /\ A

====
