---- MODULE Jp0SymbolicWordAlias ----

CONSTANTS A, B, C

Value == A /\ B \land C

====
