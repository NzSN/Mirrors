---- MODULE Jp0MixedAndOr ----

CONSTANTS A, B, C

Value == A /\ B \/ C

====
