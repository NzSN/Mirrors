---- MODULE Jp0AndChain ----

CONSTANTS A, B, C

Value == A /\ B /\ C

====
