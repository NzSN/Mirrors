---- MODULE Jp0PrefixTwoItemInlineOpposite ----

CONSTANTS A, B, C

Value == /\ A
         /\ B \/ C

====
