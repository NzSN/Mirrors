---- MODULE Jp0PrefixSwitchBack ----

CONSTANTS A, B, C

Value == /\ A
         \/ B
         /\ C

====
