---- MODULE Jp0PrefixParenthesizedOutdented ----

CONSTANTS A, B, C

Value == /\ (A
         /\ B)

====
