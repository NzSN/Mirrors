---- MODULE Jp0PrefixTwoItemMixedColumn ----

CONSTANTS A, B, C

Value == /\ A
         /\ B
         \/ C

====
